Real Time Handling Editor
=========================

A real-time vehicle handling editor for Grand Theft Auto V, intended for vehicle (handling) developers, to easily
adjust handling in-game and see the effects of the changes immediately.

Requirements
============

Grand Theft Auto V (b1604 and newer)
ScriptHookV

Optional:
Add-On Vehicle Spawner (Uses its generated hash lookup, for automatic handling names)

Installation
============
Extract RTHandlingEditor.asi and the folder HandlingEditor into the main GTA V folder.

Check the settings_menu.ini file in the HandlingEditor folder to change menu hotkeys, if desired.

Usage
=====

Use the 'rthe' cheat (without quotes) to open the menu. The cheat console can be opened with the tilde (~) key.

The menu itself should be straightforward - most options have a description.

The handling values for the current vehicle can be edited. Values can be incremented/decreased, or directly
entered by pressing 'Enter' on the option.

Certain parameters do not apply instantly - the vehicle needs to be reloaded. The main menu contains a trigger for
this: the current vehicle will be reloaded with all its tuning modifications.

The menu has options for saving the active handling to a file, or to load a handling in the "HandlingFiles" folder
inside the "HandlingEditor" folder.

The accepted XML format is one <Item> entry from a handling.meta file.

Redistribution
==============

REDISTRIBUTION OF THIS ARCHIVE IS NOT ALLOWED
MODIFICATION OF THIS ARCHIVE IS NOT ALLOWED

(C) ikt 2026
