Knight's Light armored chest rig CAGE PLATE CARRIER (CPC) from the game Escape from Tarkov

Installation: drop files in mods\x64v.rpf\models\cdimages\streamedpeds_mp.rpf\mp_m_freemode_01

!For Knight's mask check my other uploads

Credits: Battlestate games, EFT
stan_jacobs